document.querySelector("#mzy-f1-1").addEventListener('click', OpenMZYF1_1);
function OpenMZYF1_1(){
    window.open("https://detail.tmall.com/item.htm?spm=a230r.1.14.16.1ab94bf1ITLHc8&id=659094866606&ns=1&abbucket=7");
}
document.querySelector("#mzy-f1-2").addEventListener('click', OpenMZYF1_2);
function OpenMZYF1_2(){
    window.open("https://detail.tmall.com/item.htm?spm=a220m.1000858.1000725.2.dab06e53zbJ4NG&id=633823452123&skuId=4549604728102&areaId=310100&user_id=928417138&cat_id=2&is_b=1&rn=bf6ce11034d64c353b7cd7c20bcb6041");
}
document.querySelector("#mzy-f1-3").addEventListener('click', OpenMZYF1_3);
function OpenMZYF1_3(){
    window.open("https://item.taobao.com/item.htm?spm=a230r.1.14.16.2891540aPaTlBH&id=658617821852&ns=1&abbucket=7#detail");
}
document.querySelector("#mzy-f1-4").addEventListener('click', OpenMZYF1_4);
function OpenMZYF1_4(){
    window.open("https://item.taobao.com/item.htm?spm=a1z10.5-c.w4002-22619334217.11.2c216cb8oZ0tRv&id=580070448703");
}
document.querySelector("#mzy-f1-5").addEventListener('click', OpenMZYF1_5);
function OpenMZYF1_5(){
    window.open("https://item.taobao.com/item.htm?spm=a230r.1.14.3.5c2f2fa93gza8u&id=658027260801&ns=1&abbucket=7#detail");
}
document.querySelector("#mzy-f1-6").addEventListener('click', OpenMZYF1_6);
function OpenMZYF1_6(){
    window.open("https://item.taobao.com/item.htm?spm=a230r.1.14.16.6e0f572eyiiAvm&id=610201559893&ns=1&abbucket=7#detail");
}