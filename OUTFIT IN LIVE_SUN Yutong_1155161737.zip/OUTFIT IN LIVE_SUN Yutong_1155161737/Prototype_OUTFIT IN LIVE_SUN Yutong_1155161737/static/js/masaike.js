document.querySelector("#sl-msk-1").addEventListener('click', OpenSLMSK_1);
function OpenSLMSK_1(){
    window.open("https://item.taobao.com/item.htm?spm=a1z10.3-c.w4002-23244250569.9.3d6a3fe9Lo1Z1i&id=653783863778");
}

document.querySelector("#sl-msk-2").addEventListener('click', OpenSLMSK_2);
function OpenSLMSK_2(){
    window.open("https://www.christopherkane.com/hk/shopping/ecosex-t-shirt-14830164");
}


document.querySelector("#dr-msk-1").addEventListener('click', OpenDRMSK_1);
function OpenDRMSK_1(){
    window.open("https://item.taobao.com/item.htm?spm=a1z10.3-c.w4002-22872309666.9.611412dcKZoAyB&id=620246276446");
}


document.querySelector("#dr-msk-2").addEventListener('click', OpenDRMSK_2);
function OpenDRMSK_2(){
    window.open("https://item.taobao.com/item.htm?spm=a1z10.3-c.w4002-7802774117.9.645620bapzoLEI&id=652766344772");
}

document.querySelector("#dr-msk-3").addEventListener('click', OpenDRMSK_3);
function OpenDRMSK_3(){
    window.open("https://item.taobao.com/item.htm?spm=a1z10.3-c-s.w4002-15095218316.9.26bc774a3vGE6d&id=641075659734");
}

document.querySelector("#dr-msk-4").addEventListener('click', OpenDRMSK_4);
function OpenDRMSK_4(){
    window.open("https://item.taobao.com/item.htm?spm=a1z10.3-c-s.w4002-9458036224.9.5a4575ffWNG0Te&id=658093362154");
}

document.querySelector("#dr-msk-5").addEventListener('click', OpenDRMSK_5);
function OpenDRMSK_5(){
    window.open("https://item.taobao.com/item.htm?spm=a1z10.3-c-s.w4002-15560538447.9.4bda325dJdmKz0&id=629122284425");
}

document.querySelector("#dr-msk-6").addEventListener('click', OpenDRMSK_6);
function OpenDRMSK_6(){
    window.open("https://item.taobao.com/item.htm?spm=a1z10.3-c-s.w4002-18548166412.9.51db900boRTDnR&id=649786036773");
}

