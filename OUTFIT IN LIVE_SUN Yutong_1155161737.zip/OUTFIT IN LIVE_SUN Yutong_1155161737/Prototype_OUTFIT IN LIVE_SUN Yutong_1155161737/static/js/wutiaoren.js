document.querySelector("#sl-wtr-1").addEventListener('click', OpenSLWTR_1);
function OpenSLWTR_1(){
    window.open("https://item.taobao.com/item.htm?spm=a1z10.3-c-s.w4002-23155801572.39.504c7b115kROD8&id=633814385679");
}

document.querySelector("#sl-wtr-2").addEventListener('click', OpenSLWTR_2);
function OpenSLWTR_2(){
    window.open("https://item.taobao.com/item.htm?spm=a1z10.3-c-s.w4002-23155801572.54.504c7b115kROD8&id=644067587270");
}

document.querySelector("#sl-wtr-3").addEventListener('click', OpenSLWTR_3);
function OpenSLWTR_3(){
    window.open("https://item.taobao.com/item.htm?spm=a1z10.3-c-s.w4002-23795046893.15.3fd55df9Q5ZVcZ&id=646749838882");
}

document.querySelector("#sl-wtr-4").addEventListener('click', OpenSLWTR_4);
function OpenSLWTR_4(){
    window.open("https://item.taobao.com/item.htm?spm=a1z10.3-c-s.w4002-23155801572.42.504c7b115kROD8&id=634131158168");
}

document.querySelector("#dr-wtr-1").addEventListener('click', OpenDRWTR_1);
function OpenDRWTR_1(){
    window.open("https://item.taobao.com/item.htm?spm=a1z10.3-c-s.w4002-23155801572.45.504c7b115kROD8&id=638672924486");
}

document.querySelector("#dr-wtr-2").addEventListener('click', OpenDRWTR_2);
function OpenDRWTR_2(){
    window.open("https://item.taobao.com/item.htm?spm=a1z10.5-c.w4002-21762262945.11.77961630KlO84M&id=645696487378");
}


document.querySelector("#dr-wtr-3").addEventListener('click', OpenDRWTR_3);
function OpenDRWTR_3(){
    window.open("https://item.taobao.com/item.htm?spm=a1z10.3-c-s.w4002-18803762357.9.55f35f756AFOfG&id=655200668480");
}

document.querySelector("#dr-wtr-4").addEventListener('click', OpenDRWTR_4);
function OpenDRWTR_4(){
    window.open("https://item.taobao.com/item.htm?spm=a1z10.3-c-s.w4002-14941357128.9.75825da4B64UDW&id=589123807969");
}

document.querySelector("#dr-wtr-5").addEventListener('click', OpenDRWTR_5);
function OpenDRWTR_5(){
    window.open("https://item.taobao.com/item.htm?spm=a1z10.3-c-s.w4002-14941357128.9.18c15da4L7UnZd&id=629246930196");
}

document.querySelector("#dr-wtr-6").addEventListener('click', OpenDRWTR_6);
function OpenDRWTR_6(){
    window.open("https://item.taobao.com/item.htm?spm=a1z10.3-c.w4002-23445708756.9.4e8c37bcPyUK7y&id=651008465867");
}

