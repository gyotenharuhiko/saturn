document.querySelector("#sl-xkz-1").addEventListener('click', OpenXKZSL_1);
function OpenXKZSL_1(){
    window.open("https://item.taobao.com/item.htm?spm=a1z10.1-c-s.w4004-22519491508.4.cfbc59ceJgU0sf&id=556838727198");
}

document.querySelector("#sl-xkz-2").addEventListener('click', OpenXKZSL_2);
function OpenXKZSL_2(){
    window.open("https://item.taobao.com/item.htm?spm=a1z10.5-c-s.w4002-22519491524.35.796c78bdziVSoc&id=655225237862");
}

document.querySelector("#sl-xkz-3").addEventListener('click', OpenXKZSL_3);
function OpenXKZSL_3(){
    window.open("https://item.taobao.com/item.htm?spm=a1z10.3-c-s.w4002-22322767324.9.4e8a47c2BS8da2&id=613949590910");
}

document.querySelector("#sl-xkz-4").addEventListener('click', OpenXKZSL_4);
function OpenXKZSL_4(){
    window.open("https://item.taobao.com/item.htm?spm=a1z10.3-c.w4002-3568687721.9.35ec6258LGhTMI&id=565422035637");
}

document.querySelector("#sl-xkz-5").addEventListener('click', OpenXKZSL_5);
function OpenXKZSL_5(){
    window.open("https://www.yoox.com/hk/45619653/item#cod10=45619653FN&sizeId=1");
}

document.querySelector("#dr-xkz-1").addEventListener('click', OpenDRXKZ_1);
function OpenDRXKZ_1(){
    window.open("https://item.taobao.com/item.htm?spm=a1z10.1-c.w4004-21762262950.8.120674dfp7FDBC&id=606212221392");
}

document.querySelector("#dr-xkz-2").addEventListener('click', OpenDRXKZ_2);
function OpenDRXKZ_2(){
    window.open("https://item.taobao.com/item.htm?spm=a1z10.3-c-s.w4002-22322767324.12.4a2747c2d8BBuS&id=624689674277");
}

document.querySelector("#dr-xkz-3").addEventListener('click', OpenDRXKZ_3);
function OpenDRXKZ_3(){
    window.open("https://item.taobao.com/item.htm?spm=a1z10.3-c-s.w4002-22322767324.9.373447c23wkVHX&id=602836588428");
}

document.querySelector("#dr-xkz-4").addEventListener('click', OpenDRXKZ_4);
function OpenDRXKZ_4(){
    window.open("https://item.taobao.com/item.htm?spm=a1z10.3-c-s.w4002-23082611936.9.73df7abdLk8N48&id=657826836069");
}

document.querySelector("#dr-xkz-5").addEventListener('click', OpenDRXKZ_5);
function OpenDRXKZ_5(){
    window.open("https://item.taobao.com/item.htm?spm=a230r.1.14.1.cd705e9eIQX8qP&id=626933582005&ns=1&abbucket=7#detail");
}

document.querySelector("#dr-xkz-6").addEventListener('click', OpenDRXKZ_6);
function OpenDRXKZ_6(){
    window.open("https://item.taobao.com/item.htm?spm=a1z10.3-c-s.w4002-14534005687.9.5e2d6f6a4NaUwB&id=652879207962");
}


